
import L from 'leaflet';

// Custom Icons
export const createCustomIcon = (color: string) => new L.Icon({
    iconUrl: `https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-${color}.png`,
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41]
});

// Helper for unique user colors
export const stringToColor = (str: string) => {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    // Fixed S and L for consistency, H varies
    const h = Math.abs(hash) % 360;
    return `hsl(${h}, 70%, 50%)`;
};

// Create SVG marker with dynamic color
export const createDynamicIcon = (color: string) => L.divIcon({
    className: 'custom-div-icon',
    html: `
        <div style="filter: drop-shadow(0 2px 3px rgba(0,0,0,0.3));">
            <svg width="30" height="30" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 21C16 16.5 19 13.5229 19 10C19 6.13401 15.866 3 12 3C8.13401 3 5 6.13401 5 10C5 13.5229 8 16.5 12 21Z" fill="${color}" stroke="white" stroke-width="1.5"/>
                <circle cx="12" cy="10" r="3" fill="white"/>
            </svg>
        </div>
    `,
    iconSize: [30, 30],
    iconAnchor: [15, 30],
    popupAnchor: [0, -30]
});

export const getDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371e3; // meters
    const φ1 = lat1 * Math.PI / 180;
    const φ2 = lat2 * Math.PI / 180;
    const Δφ = (lat2 - lat1) * Math.PI / 180;
    const Δλ = (lon2 - lon1) * Math.PI / 180;

    const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
        Math.cos(φ1) * Math.cos(φ2) *
        Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c; // in meters
};

export const Icons = {
    team: createCustomIcon('blue'),
    customer: createCustomIcon('green'),
    transaction: createCustomIcon('red'), // Sales
    active: createCustomIcon('gold') 
};
