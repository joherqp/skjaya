import { useState, useMemo, useCallback } from 'react';
import { useDatabase } from '@/contexts/DatabaseContext';
import { useAuth } from '@/contexts/AuthContext';
import type { Barang as BarangType } from '@/lib/types';

export const useBarangManagement = () => {
    const { user } = useAuth();
    const { barang, satuan: satuanList, stokPengguna, penjualan, kategori: kategoriList, cabang, users } = useDatabase();
    
    // -- Access Control --
    const isAdminOrOwner = user?.roles.includes('admin') || user?.roles.includes('owner');

    // -- Filters State --
    const [search, setSearch] = useState('');
    const [filterKategori, setFilterKategori] = useState<string[]>([]);
    const [filterStok, setFilterStok] = useState<string[]>([]);
    const [filterCabang, setFilterCabang] = useState<string[]>([]);
    const [showInactive, setShowInactive] = useState(false);

    // -- Logic Calculators --
    const getStockHealth = useCallback((barangId: string, currentStock: number) => {
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        
        // 1. Calculate Sales in last 30 days
        const relevantSales = penjualan.filter(p => 
            new Date(p.tanggal) >= thirtyDaysAgo && 
            p.status !== 'batal' &&
            (isAdminOrOwner ? true : p.salesId === user?.id)
        );
        
        let totalSold = 0;
        relevantSales.forEach(sale => {
            const item = sale.items.find(i => i.barangId === barangId);
            if (item) totalSold += item.jumlah;
        });

        const b = barang.find(x => x.id === barangId);
        const minStok = b?.minStok || 0;

        let status: 'aman' | 'warning' | 'critical' = 'aman';
        const avgDailySales = totalSold / 30;
        const daysCoverage = avgDailySales > 0 ? currentStock / avgDailySales : 999; 

        // 2. Hybrid Logic
        if (totalSold > 0) {
            // Velocity-based logic: prioritized for "permintaan pasar"
            if (daysCoverage < 7) status = 'critical';
            else if (daysCoverage < 14) status = 'warning';
        } 
        
        // Always check against minStok (safety net)
        if (status === 'aman') {
            if (currentStock <= minStok * 0.5) status = 'critical';
            else if (currentStock <= minStok) status = 'warning';
        }

        return { 
            avgDailySales, 
            daysCoverage, 
            status, 
            demandLevel: avgDailySales > 5 ? 'Tinggi' : avgDailySales > 2 ? 'Sedang' : totalSold > 0 ? 'Rendah' : 'Tidak Ada Penjualan' 
        };
    }, [penjualan, user?.id, isAdminOrOwner, barang]);

    // -- Data Filtering --
    const filteredBarang = useMemo(() => {
        return barang.filter(b => {
            const matchesSearch = b.nama.toLowerCase().includes(search.toLowerCase()) || b.kode.toLowerCase().includes(search.toLowerCase());
            const matchesKategori = filterKategori.length === 0 || filterKategori.includes(b.kategoriId);
            const matchesActive = showInactive ? true : (b.isActive !== false); 
            
            return matchesSearch && matchesKategori && matchesActive;
        });
    }, [barang, search, filterKategori, showInactive]);

    const activeFiltersCount = [
        filterKategori.length > 0,
        filterStok.length > 0,
        filterCabang.length > 0
    ].filter(Boolean).length;

    // -- Display Logic (Global vs Personal) --
    const displayedItems = useMemo(() => {
        // 1. Admin / Owner / Gudang -> Global or Branch-specific
        if (isAdminOrOwner) {
            if (filterCabang.length === 0) {
                // Global Master Stock + All User Stocks
                return filteredBarang.map(item => {
                    let consolidatedStock = item.stok || 0; 
                    stokPengguna.filter(s => s.barangId === item.id)
                                .forEach(s => consolidatedStock += s.jumlah);

                    const globalItem = { ...item, stok: consolidatedStock };
                    
                    if (filterStok.length > 0) {
                        const health = getStockHealth(globalItem.id, globalItem.stok);
                        if (filterStok.includes('aman') && health.status === 'aman') return globalItem;
                        if (filterStok.includes('rendah') && health.status !== 'aman') return globalItem;
                        return null;
                    }
                    return globalItem;
                }).filter((item): item is (BarangType & { stok: number }) => item !== null);
            } else {
                // Specific Branch Stock
                const branchUserIds = users.filter(u => filterCabang.includes(u.cabangId)).map(u => u.id);
                const isPusatSelected = cabang.some(c => filterCabang.includes(c.id) && c.nama.toLowerCase().includes('pusat'));

                return filteredBarang.map(item => {
                    let branchStock = 0;
                    stokPengguna.filter(s => s.barangId === item.id && branchUserIds.includes(s.userId))
                                .forEach(s => branchStock += s.jumlah);

                    if (isPusatSelected) {
                        branchStock += (item.stok || 0);
                    }

                    const branchItem = { ...item, stok: branchStock };

                    if (filterStok.length > 0) {
                        const health = getStockHealth(branchItem.id, branchItem.stok);
                        if (filterStok.includes('aman') && health.status === 'aman') return branchItem;
                        if (filterStok.includes('rendah') && health.status !== 'aman') return branchItem;
                        return null;
                    }
                    return branchItem;
                }).filter((item): item is (BarangType & { stok: number }) => item !== null)
                  .sort((a, b) => (b.stok || 0) - (a.stok || 0)); 
            }
        }

        // 2. Sales / Staff -> Personal Stock
        return filteredBarang.map(item => {
            const myStock = stokPengguna.find(s => s.userId === user?.id && s.barangId === item.id);
            const quantity = myStock ? myStock.jumlah : 0;
            const personalItem = { ...item, stok: quantity };
            
            if (filterStok.length > 0) {
                const health = getStockHealth(personalItem.id, personalItem.stok);
                if (filterStok.includes('aman') && health.status === 'aman') return personalItem;
                if (filterStok.includes('rendah') && health.status !== 'aman') return personalItem;
                return null;
            }

            return personalItem;
        }).filter((item): item is (BarangType & { stok: number }) => item !== null)
          .sort((a, b) => (b.stok || 0) - (a.stok || 0)); 

    }, [filteredBarang, stokPengguna, user, isAdminOrOwner, filterStok, filterCabang, users, cabang, getStockHealth]);

    return {
        // State
        search, setSearch,
        filterKategori, setFilterKategori,
        filterStok, setFilterStok,
        filterCabang, setFilterCabang,
        showInactive, setShowInactive,
        activeFiltersCount,
        
        // Data
        displayedItems,
        kategoriList,
        satuanList,
        cabangList: cabang,
        
        // Utils
        isAdminOrOwner,
        getStockHealth
    };
};
