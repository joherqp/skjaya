
import { useDatabase } from '@/contexts/DatabaseContext';
import { useAuth } from '@/contexts/AuthContext';

export function usePricing() {
    const { pelanggan, barang, harga, promo } = useDatabase();
    const { user } = useAuth();

    const getPriceDetailed = (
        productId: string, 
        unitId: string | undefined, 
        qty: number, 
        conversion: number, 
        customerId: string, 
        totalMixMatchQty: number, 
        productQtyBase?: number
    ): { price: number, tier?: { min: number; max: number; harga: number; isMixMatch?: boolean } } => {
        const selectedCustomer = pelanggan.find(p => p.id === customerId);
        const product = barang.find(b => b.id === productId);
        
        const findRule = (targetUnitId: string | undefined) => {
            if (!targetUnitId) return undefined;
            const rules = harga.filter(h => 
                h.barangId === productId && 
                h.satuanId === targetUnitId &&
                h.status === 'disetujui' &&
                new Date(h.tanggalEfektif) <= new Date() &&
                (!h.kategoriPelangganIds || (selectedCustomer && h.kategoriPelangganIds.includes(selectedCustomer.kategoriId))) &&
                (!h.cabangId || h.cabangId === user?.cabangId)
            );
            rules.sort((a, b) => (b.cabangId ? 1 : 0) - (a.cabangId ? 1 : 0));
            return rules[0];
        };

        let matchedRule = findRule(unitId);
        let usingBaseRule = false;

        if (!matchedRule && product && unitId !== product.satuanId) {
            matchedRule = findRule(product.satuanId);
            usingBaseRule = true;
        }

        if (matchedRule) {
            let price = matchedRule.harga;
            let tierVal: { min: number; max: number; harga: number; isMixMatch?: boolean } | undefined;

            if (matchedRule.grosir && matchedRule.grosir.length > 0) {
                const sortedTiers = [...matchedRule.grosir].sort((a, b) => b.min - a.min);
                // Logic: use total combined qty of this product in cart for tier calculation
                const totalQtyInBaseForTier = productQtyBase !== undefined ? productQtyBase : (qty * conversion);
                
                tierVal = sortedTiers.find(g => {
                    const quantityToCheck = g.isMixMatch ? totalMixMatchQty : totalQtyInBaseForTier;
                    return quantityToCheck >= g.min;
                });

                if (tierVal) price = tierVal.harga;
            }
            if (usingBaseRule) return { price: price * conversion, tier: tierVal };
            return { price, tier: tierVal };
        }
        return { price: 0 };
    };

    const getPromo = (
        productId: string, 
        price: number, 
        qty: number, 
        conversion: number, 
        productQtyBase?: number, 
        selectedPromoId?: string
    ): { 
        discount: number, 
        bonus?: { 
            productIds: string[], 
            qty: number, 
            mechanism: 'random' | 'single' | 'mix',
            promoId: string 
        },
        availablePromos: { id: string; nama: string; tipe: string; nilai: number; bonusProdukIds?: string[]; isBest?: boolean }[],
        appliedPromoId?: string
    } => {
        const now = new Date();
        const totalInBase = productQtyBase !== undefined ? productQtyBase : (qty * conversion);
        const currentRowInBase = qty * conversion;
        
        const activePromos = promo.filter(p => {
            if (!p.isActive) return false;
            const start = new Date(p.tanggalMulai);
            const end = p.tanggalBerakhir ? new Date(p.tanggalBerakhir) : null;
            if (start > now || (end && end < now)) return false;
            if (p.scope === 'selected_products' && p.targetProdukIds && !p.targetProdukIds.includes(productId)) return false;
            if (p.cabangId && p.cabangId !== user?.cabangId) return false;
            if (p.minQty && totalInBase < p.minQty) return false;
            return true;
        });

        // Calculate potential of EACH promo
        const candidates = activePromos.map(p => {
            let potentialDiscount = 0;
            let potentialBonus = undefined;

            if (p.tipe === 'persen') {
                const gross = price * qty;
                potentialDiscount = gross * (p.nilai / 100);
            } else if (p.tipe === 'nominal') {
                if (p.isKelipatan) {
                    const effectiveMinQty = p.minQty && p.minQty > 0 ? p.minQty : 1;
                    const multiplier = Math.floor(totalInBase / effectiveMinQty);
                    const totalDiscount = multiplier * p.nilai;
                    potentialDiscount = totalInBase > 0 ? totalDiscount * (currentRowInBase / totalInBase) : 0;
                } else {
                    potentialDiscount = totalInBase > 0 ? p.nilai * (currentRowInBase / totalInBase) : 0;
                }
            } else if (p.tipe === 'produk') {
                const effectiveMinQty = p.minQty && p.minQty > 0 ? p.minQty : 1;
                let bonusCount = 0;
                if (p.isKelipatan) {
                    bonusCount = Math.floor(totalInBase / effectiveMinQty) * (p.nilai && p.nilai > 0 ? p.nilai : 1);
                } else {
                    bonusCount = (p.nilai && p.nilai > 0 ? p.nilai : 1);
                }
                
                if (bonusCount > 0) {
                    const productOptions = p.bonusProdukIds && p.bonusProdukIds.length > 0 ? p.bonusProdukIds : (p.bonusProdukId ? [p.bonusProdukId] : []);
                    if (productOptions.length > 0) {
                        potentialBonus = { 
                            productIds: productOptions, 
                            qty: bonusCount,
                            mechanism: p.mekanismeBonus || 'random',
                            promoId: p.id
                        };
                    }
                }
            }

            // Evaluate value for "Best" determination (approximate value of bonus?)
            // For now, we mainly compare discount. For bonus, we might prioritize it if discount is 0.
            const valueScore = potentialDiscount > 0 ? potentialDiscount : (potentialBonus ? 999999 : 0); // Bonus is considered "high value"

            return { p, potentialDiscount, potentialBonus, valueScore };
        });

        // Sort by value score desc
        candidates.sort((a, b) => b.valueScore - a.valueScore);

        const availablePromos = candidates.map((c, idx) => ({
            id: c.p.id,
            nama: c.p.nama,
            tipe: c.p.tipe,
            nilai: c.p.nilai,
            bonusProdukIds: c.p.bonusProdukIds || (c.p.bonusProdukId ? [c.p.bonusProdukId] : []),
            isBest: idx === 0
        }));

        // Determine Which to Apply
        let selectedCandidate = candidates[0]; // Default to best

        if (selectedPromoId === 'NONE') {
            return { discount: 0, availablePromos };
        }
        
        if (selectedPromoId) {
            const found = candidates.find(c => c.p.id === selectedPromoId);
            if (found) {
                selectedCandidate = found;
            } else {
                // Selected promo no longer valid? Fallback to Best or None?
                // Let's fallback to Best for continuity, or None? Best is safer.
            }
        }

        if (!selectedCandidate) {
            return { discount: 0, availablePromos };
        }

        return { 
            discount: selectedCandidate.potentialDiscount, 
            bonus: selectedCandidate.potentialBonus, 
            availablePromos,
            appliedPromoId: selectedCandidate.p.id
        };
    };

    return { getPriceDetailed, getPromo };
}
