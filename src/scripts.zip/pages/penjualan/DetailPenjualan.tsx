import { useCallback, useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layout/MainLayout';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { PembayaranPenjualan, Penjualan, PenjualanItem } from '@/lib/types';
import { formatRupiah, formatTanggal, formatWaktu, cn } from '@/lib/utils';
import { supabase } from '@/lib/supabase';
import { Share2, Printer, ArrowLeft, Calendar, Loader2, DollarSign, History, CreditCard, MapPin, User, ShoppingBag } from 'lucide-react';
import { toast } from 'sonner';
import { useDatabase } from '@/contexts/DatabaseContext';
import { useAuth } from '@/contexts/AuthContext';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

export default function DetailPenjualan() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { 
    penjualan, 
    pelanggan, 
    users, 
    barang, 
    satuan, 
    cabang, 
    profilPerusahaan,
    addPembayaranPenjualan,
    isAdminOrOwner
  } = useDatabase();
  const { user: currentUser } = useAuth();

  const [trx, setTrx] = useState<Penjualan | null>(null);
  const [loading, setLoading] = useState(true);
  const [isRepaymentOpen, setIsRepaymentOpen] = useState(false);
  const [isRepaymentConfirmOpen, setIsRepaymentConfirmOpen] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState(0);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const [isFinalizeOpen, setIsFinalizeOpen] = useState(false);
  const [cancellationReason, setCancellationReason] = useState('');
  const [isSubmittingPayment, setIsSubmittingPayment] = useState(false);
  const [paymentHistory, setPaymentHistory] = useState<PembayaranPenjualan[]>([]);
  const [showPrintReceipt, setShowPrintReceipt] = useState(false);

  const fetchTrx = useCallback(() => {
    if (!id) return;
    const found = penjualan.find(p => p.id === id);
    if (found) {
      setTrx(found);
      // Fetch history logic here if needed, or from context
    }
    setLoading(false);
  }, [id, penjualan]);

  useEffect(() => {
    fetchTrx();
  }, [fetchTrx]);

  const fetchPaymentHistory = useCallback(async () => {
    if (!id) return;
    try {
      const { data, error } = await supabase
        .from('pembayaran_penjualan')
        .select('*')
        .eq('penjualan_id', id)
        .order('tanggal', { ascending: false });
      if (error) throw error;
      setPaymentHistory(data || []);
    } catch (err) {
      console.error(err);
    }
  }, [id]);

  useEffect(() => {
    if (id) fetchPaymentHistory();
  }, [id, fetchPaymentHistory]);

  const handleRepayment = async () => {
     if (!trx || paymentAmount <= 0) return;
     setIsSubmittingPayment(true);
     try {
        await addPembayaranPenjualan({
            penjualanId: trx.id,
            jumlah: paymentAmount,
            metodePembayaran: 'transfer', // Default or pickable
            tanggal: new Date(),
            createdBy: currentUser?.id || 'system'
        });
        toast.success("Pembayaran berhasil disimpan");
        setIsRepaymentOpen(false);
        setIsRepaymentConfirmOpen(false);
        setPaymentAmount(0);
        fetchPaymentHistory();
     } catch (err) {
        console.error(err);
        toast.error("Gagal menyimpan pembayaran");
     } finally {
        setIsSubmittingPayment(false);
     }
  };

  const handleAjukanPembatalan = () => {
      toast.info("Fitur pembatalan segera hadir");
      setIsConfirmOpen(false);
  };

  const handleFinalize = (useToday: boolean) => {
      toast.info(`Finalize with ${useToday ? 'Today' : 'Draft Date'} toggle...`);
      setIsFinalizeOpen(false);
  };

  const handleShare = async () => {
      if (!trx) return;

      const customer = pelanggan.find(p => p.id === trx.pelangganId);
      const items = trx.items.map(item => {
          const product = barang.find(b => b.id === item.barangId);
          const unit = satuan.find(s => s.id === item.satuanId);
          return `• ${product?.nama || 'Item'} (${item.jumlah} ${unit?.simbol || 'pcs'}) - ${formatRupiah(item.subtotal)}`;
      }).join('\n');

      const shareText = `📄 *NOTA PENJUALAN*
━━━━━━━━━━━━━━━━━━
📌 No: ${trx.nomorNota}
📅 Tanggal: ${formatTanggal(trx.tanggal)}
👤 Pelanggan: ${customer?.nama || 'Umum'}

📦 *Rincian Barang:*
${items}

━━━━━━━━━━━━━━━━━━
💰 *Total: ${formatRupiah(trx.total)}*
💵 Bayar: ${formatRupiah(trx.bayar || 0)}
📊 Status: ${trx.isLunas ? '✅ LUNAS' : '⏳ Belum Lunas'}
━━━━━━━━━━━━━━━━━━
${profilPerusahaan.nama}`;

      if (navigator.share) {
          try {
              await navigator.share({
                  title: `Nota ${trx.nomorNota}`,
                  text: shareText,
              });
              toast.success('Berhasil dibagikan');
          } catch (err) {
              if ((err as Error).name !== 'AbortError') {
                  console.error('Share failed:', err);
              }
          }
      } else {
          // Fallback: Copy to clipboard
          try {
              await navigator.clipboard.writeText(shareText);
              toast.success('Teks nota disalin ke clipboard');
          } catch (err) {
              toast.error('Gagal menyalin teks');
              console.error(err);
          }
      }
  };

  const salesName = users.find(u => u.id === trx?.salesId)?.nama || 'Unknown';
  const customer = pelanggan.find(p => p.id === trx?.pelangganId);
  const branch = cabang.find(c => c.id === trx?.cabangId);
  const isAssociatedUser = isAdminOrOwner || trx?.salesId === currentUser?.id;

  if (loading) return <div className="p-8 text-center">Memuat nota...</div>;
  if (!trx) return <div className="p-8 text-center text-destructive">Nota tidak ditemukan.</div>;

  return (
    <MainLayout title={`Nota ${trx.nomorNota}`}>
        {/* Printable Receipt */}
        <div className={cn("hidden print:block print:fixed print:top-0 print:left-0 print:w-full print:h-full print:bg-white print:z-[99999] print:p-0", showPrintReceipt ? 'block' : 'hidden')}>
            <div className="w-[58mm] mx-auto p-2 text-black font-mono text-[10px] leading-tight">
                <div className="text-center mb-2">
                    <h1 className="font-bold text-sm uppercase">{profilPerusahaan.nama}</h1>
                    <p className="text-[8px]">{branch?.alamat || profilPerusahaan.alamat}</p>
                    <p className="text-[8px]">{branch?.telepon || profilPerusahaan.telepon}</p>
                </div>
                <Separator className="border-black mb-2" />
                <div className="flex justify-between mb-1">
                    <span>{trx.nomorNota}</span>
                    <span>{new Date(trx.tanggal).toLocaleDateString()}</span>
                </div>
                <div className="mb-2">CS: {customer?.nama || 'UMUM'}</div>
                <Separator className="border-black border-dashed mb-2" />
                <div className="space-y-1">
                    {trx.items.map((item, idx) => {
                        const product = barang.find(b => b.id === item.barangId);
                        const unit = satuan.find(s => s.id === item.satuanId);
                        return (
                            <div key={idx} className="flex flex-col">
                                <div className="flex justify-between">
                                    <span className="flex-1 pr-2">{product?.nama || item.barangId}</span>
                                    <span>{formatRupiah(item.subtotal)}</span>
                                </div>
                                <div className="text-[8px] text-gray-600 pl-2">
                                    {item.jumlah} {unit?.simbol} x {formatRupiah(item.harga)}
                                    {item.diskon > 0 && ` (-${formatRupiah(item.diskon)})`}
                                </div>
                                {item.isBonus && <div className="text-[8px] font-bold italic pl-2 ml-2 border-l border-black">*** ITEM BONUS ***</div>}
                            </div>
                        );
                    })}
                </div>
                <Separator className="border-black border-dashed my-2" />
                <div className="space-y-0.5">
                    <div className="flex justify-between text-xs font-bold">
                        <span>TOTAL</span>
                        <span>{formatRupiah(trx.total)}</span>
                    </div>
                    <div className="flex justify-between">
                        <span>Bayar</span>
                        <span>{formatRupiah(trx.bayar || 0)}</span>
                    </div>
                </div>
                <Separator className="border-black my-2" />
                <div className="text-center text-[8px] space-y-1">
                    <p>Terima kasih atas kunjungan Anda</p>
                    <p>Barang yang sudah dibeli tidak dapat dikembalikan</p>
                </div>
            </div>
        </div>

        <div className="p-4 space-y-4 print:hidden max-w-4xl mx-auto">
            <Card className="overflow-hidden shadow-lg border-primary/20">
                <CardHeader className="bg-gradient-to-br from-primary/10 via-background to-background pb-8 relative border-b">
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                        <div className="space-y-3 flex-1 w-full">
                            <div className="flex items-center gap-3">
                                <h1 className="text-2xl md:text-3xl font-black tracking-tighter text-primary">{trx.nomorNota}</h1>
                                <div className={`px-4 py-1.5 rounded-full text-sm font-bold uppercase ${
                                    trx.status === 'lunas' ? 'bg-green-100 text-green-700' : 
                                    trx.status === 'batal' ? 'bg-red-100 text-red-700' : 'bg-orange-100 text-orange-700'
                                }`}>
                                    {trx.status}
                                </div>
                            </div>
                            <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-muted-foreground text-sm">
                                <div className="flex items-center gap-2 font-medium">
                                    <Calendar className="w-4 h-4 text-primary/60" />
                                    <span>{formatTanggal(trx.tanggal)}</span>
                                    <span className="opacity-60">{formatWaktu(trx.tanggal)}</span>
                                </div>
                                <div className="flex items-center gap-2 font-medium">
                                    <User className="w-4 h-4 text-primary/60" />
                                    <span>{salesName}</span>
                                </div>
                            </div>
                        </div>
                        <div className="flex flex-col items-end gap-2 w-full md:w-auto">
                            <div className="flex flex-col items-end gap-1">
                                {trx.metodePembayaran === 'tempo' && (
                                    <div className={`px-3 py-1 rounded text-xs font-black uppercase border ${
                                        trx.isLunas ? 'bg-green-50 text-green-600 border-green-200' : 'bg-red-50 text-red-600 border-red-200'
                                    }`}>
                                        {trx.isLunas ? 'Lunas' : 'Belum Lunas'}
                                    </div>
                                )}
                                <div className="text-2xl font-black text-right text-primary">
                                    {formatRupiah(trx.total)}
                                </div>
                            </div>
                        </div>
                    </div>
                </CardHeader>
                <CardContent className="p-0">
                    <div className="grid grid-cols-1 md:grid-cols-2">
                        <div className="p-6 border-b md:border-b-0 md:border-r space-y-4">
                            <h3 className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4">Informasi Pelanggan</h3>
                            <div className="space-y-4">
                                <div className="flex items-start gap-4">
                                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                                        <User className="w-5 h-5 text-primary" />
                                    </div>
                                    <div className="flex-1">
                                        <p className="text-sm font-bold">{customer?.nama || 'UMUM'}</p>
                                        <p className="text-xs text-muted-foreground">{customer?.telepon || '-'}</p>
                                    </div>
                                </div>
                                <div className="flex items-start gap-4">
                                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                                        <MapPin className="w-5 h-5 text-primary" />
                                    </div>
                                    <div className="flex-1">
                                        <p className="text-sm text-foreground/80 leading-relaxed">{customer?.alamat || '-'}</p>
                                        {trx.lokasi && (
                                            <a 
                                                href={`https://www.google.com/maps?q=${trx.lokasi.latitude},${trx.lokasi.longitude}`}
                                                target="_blank"
                                                rel="noreferrer"
                                                className="inline-flex items-center gap-1 text-[10px] text-blue-500 font-bold hover:underline mt-1 uppercase"
                                            >
                                                <MapPin className="w-3 h-3" /> Lokasi Transaksi
                                            </a>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="p-6 space-y-4 bg-muted/5">
                            <h3 className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4">Status & Pembayaran</h3>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-1">
                                    <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-tight">Metode</p>
                                    <div className="flex items-center gap-2">
                                        <CreditCard className="w-4 h-4 text-primary" />
                                        <span className="text-sm font-bold uppercase">{trx.metodePembayaran}</span>
                                    </div>
                                </div>
                                <div className="space-y-1">
                                    <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-tight">Status</p>
                                    <Badge variant={trx.status === 'lunas' ? 'success' : trx.status === 'draft' ? 'warning' : 'destructive'} className="uppercase font-black animate-pulse-subtle">
                                        {trx.status}
                                    </Badge>
                                </div>
                            </div>
                            <Separator />
                            <div className="space-y-2">
                                 <div className="flex justify-between text-sm">
                                    <span className="text-muted-foreground">Total Item</span>
                                    <span className="font-bold">{trx.items.length} Macam</span>
                                 </div>
                                 <div className="flex justify-between text-sm">
                                    <span className="text-muted-foreground">Qty Keseluruhan</span>
                                    <span className="font-bold">{trx.items.reduce((s, i) => s + i.jumlah, 0)}</span>
                                 </div>
                            </div>
                        </div>
                    </div>

                    <div className="p-0 overflow-x-auto border-y">
                        <Table>
                            <TableHeader className="bg-muted/50">
                                <TableRow>
                                    <TableHead className="w-[50px] text-center pl-6">#</TableHead>
                                    <TableHead>Nama Barang</TableHead>
                                    <TableHead className="text-center">Qty</TableHead>
                                    <TableHead className="text-right">Harga</TableHead>
                                    <TableHead className="text-right">Potongan</TableHead>
                                    <TableHead className="text-right pr-6">Subtotal</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {trx.items.map((item, idx) => {
                                    const product = barang.find(b => b.id === item.barangId);
                                    const unit = satuan.find(s => s.id === item.satuanId);
                                    return (
                                        <TableRow key={idx} className={cn("group", item.isBonus && "bg-blue-50/50")}>
                                            <TableCell className="text-center text-muted-foreground font-mono pl-6">{idx + 1}</TableCell>
                                            <TableCell>
                                                <div className="flex flex-col">
                                                    <span className="font-bold group-hover:text-primary transition-colors">
                                                        {product?.nama || item.barangId}
                                                    </span>
                                                    <span className="text-[10px] text-muted-foreground font-mono bg-muted inline-block px-1 rounded w-fit">
                                                        {product?.kode || '-'}
                                                    </span>
                                                    {item.isBonus && (
                                                        <span className="text-[10px] font-black text-blue-600 bg-blue-100 px-1.5 py-0.5 rounded-full mt-1 w-fit uppercase flex items-center gap-1">
                                                            <ShoppingBag className="w-3 h-3" /> Bonus Promo
                                                        </span>
                                                    )}
                                                </div>
                                            </TableCell>
                                            <TableCell className="text-center">
                                                <span className="font-bold">{item.jumlah}</span>
                                                <span className="text-xs text-muted-foreground ml-1">{unit?.simbol}</span>
                                            </TableCell>
                                            <TableCell className="text-right font-mono text-xs">{formatRupiah(item.harga)}</TableCell>
                                            <TableCell className="text-right font-mono text-xs text-red-500">
                                                {item.diskon > 0 ? `-${formatRupiah(item.diskon)}` : '-'}
                                            </TableCell>
                                            <TableCell className="text-right font-bold pr-6 font-mono">{formatRupiah(item.subtotal)}</TableCell>
                                        </TableRow>
                                    );
                                })}
                            </TableBody>
                        </Table>
                    </div>

                    <div className="p-6 bg-muted/5">
                        <div className="flex flex-col md:flex-row justify-between items-start gap-8">
                             <div className="flex-1 w-full max-w-sm space-y-4">
                                {trx.catatan && (
                                    <div className="bg-yellow-50 p-4 rounded-xl border border-yellow-200">
                                        <p className="text-[10px] font-bold text-yellow-800 uppercase mb-1 tracking-wider">Catatan</p>
                                        <p className="text-xs italic text-yellow-700 leading-relaxed">"{trx.catatan}"</p>
                                    </div>
                                )}
                             </div>
                             
                             <div className="w-full md:w-80 space-y-3">
                                <div className="flex justify-between text-sm py-1">
                                    <span className="text-muted-foreground">Total Penjualan</span>
                                    <span className="font-bold font-mono">{formatRupiah(trx.total)}</span>
                                </div>
                                <div className="flex justify-between text-sm py-1 border-t border-dashed">
                                    <span className="text-muted-foreground">Sudah Dibayar</span>
                                    <span className="font-bold font-mono text-green-600">
                                        {formatRupiah(paymentHistory.reduce((sum, p) => sum + Number(p.jumlah), 0) + (trx.bayar || 0))}
                                    </span>
                                </div>
                                <Separator />
                                <div className="flex justify-between items-center py-2">
                                     <span className="text-base font-black uppercase text-primary">Sisa Hutang</span>
                                     <span className="text-xl font-black font-mono text-red-600">
                                        {formatRupiah(Math.max(0, trx.total - (paymentHistory.reduce((sum, p) => sum + Number(p.jumlah), 0) + (trx.bayar || 0))))}
                                     </span>
                                </div>
                             </div>
                        </div>
                    </div>
                </CardContent>
                <CardFooter className="flex flex-col gap-4 bg-muted/30 border-t pt-6">
                    <div className="flex flex-wrap gap-2 w-full justify-center">
                        <Button 
                            variant="outline" 
                            size="sm" 
                            className="flex-1 min-w-[120px]"
                            onClick={() => navigate('/penjualan')}
                        >
                            <ArrowLeft className="w-4 h-4 mr-2" /> Kembali
                        </Button>
                        
                        {trx.metodePembayaran === 'tempo' && !trx.isLunas && isAssociatedUser && (
                           <Button 
                               variant="default" 
                               size="sm"
                               className="flex-1 min-w-[120px] bg-green-600 hover:bg-green-700"
                               onClick={() => setIsRepaymentOpen(true)}
                           >
                               <DollarSign className="w-4 h-4 mr-2" /> Bayar Sisa
                           </Button>
                        )}

                        <Button 
                            variant="outline" 
                            size="sm"
                            className="flex-1 min-w-[120px]"
                            onClick={handleShare}
                        >
                            <Share2 className="w-4 h-4 mr-2" /> Bagikan
                        </Button>

                        <Button 
                            variant="default" 
                            size="sm"
                            className="flex-1 min-w-[120px]"
                            onClick={() => {
                               setShowPrintReceipt(true);
                               setTimeout(() => {
                                   window.print();
                                   setShowPrintReceipt(false);
                               }, 300);
                            }}
                        >
                            <Printer className="w-4 h-4 mr-2" /> Cetak Struk
                        </Button>
                    </div>

                    <div className="flex flex-col sm:flex-row justify-end print:hidden gap-3 w-full">
                        {trx.status === 'draft' && (
                            <Button className="w-full sm:w-auto bg-primary hover:bg-primary/90 order-1 sm:order-none" onClick={() => setIsFinalizeOpen(true)}>
                                Selesaikan (Bukan Draft)
                            </Button>
                        )}
                        {trx.status !== 'batal' && isAssociatedUser && (
                            <Button variant="destructive" className="w-full sm:w-auto order-2 sm:order-none" onClick={() => setIsConfirmOpen(true)}>
                                {trx.status === 'draft' ? "Batalkan Draft" : "Ajukan Pembatalan"}
                            </Button>
                        )}
                        {(trx.status === 'pending' || trx.status === 'draft') && (
                            <Button onClick={() => setIsFinalizeOpen(true)} className="mt-4 w-full">
                                <DollarSign className="w-4 h-4 mr-2" />
                                Selesaikan Transaksi
                            </Button>
                        )}
                    </div>
                </CardFooter>
            </Card>

            <Dialog open={isHistoryOpen} onOpenChange={setIsHistoryOpen}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Riwayat Pembayaran</DialogTitle>
                    </DialogHeader>
                    <div className="py-2">
                        <div className="bg-muted/30 p-3 rounded-lg flex justify-between items-center mb-4">
                            <span className="text-sm text-muted-foreground">Total Tagihan</span>
                            <span className="font-bold">{formatRupiah(trx.total)}</span>
                        </div>
                        <h4 className="text-sm font-semibold mb-2">Daftar Pembayaran</h4>
                        <ScrollArea className="h-[200px] border rounded-md p-2">
                             {paymentHistory.length === 0 ? (
                                <p className="text-center text-xs text-muted-foreground py-4">Belum ada pembayaran.</p>
                             ) : (
                                <div className="space-y-3">
                                    {paymentHistory.map((ph, idx) => (
                                        <div key={ph.id || idx} className="text-sm flex justify-between items-start border-b pb-2 last:border-0 border-dashed">
                                            <div>
                                                <div className="flex items-center gap-1.5 font-medium">
                                                    <span>{formatTanggal(ph.tanggal)}</span>
                                                    <span className="text-xs text-muted-foreground font-normal">{formatWaktu(ph.tanggal)}</span>
                                                </div>
                                                <div className="flex items-center gap-1 text-[10px] text-muted-foreground mt-0.5 capitalize">
                                                    {ph.metodePembayaran || 'Transfer'}
                                                </div>
                                            </div>
                                            <span className="font-bold text-green-600">+{formatRupiah(ph.jumlah)}</span>
                                        </div>
                                    ))}
                                </div>
                             )}
                        </ScrollArea>
                        <div className="flex justify-between items-center mt-4 pt-2 border-t font-semibold">
                            <span>Total Terbayar</span>
                            <span className="text-green-600">{formatRupiah(paymentHistory.reduce((sum, p) => sum + Number(p.jumlah), 0) + (trx.bayar || 0))}</span>
                        </div>
                    </div>
                </DialogContent>
            </Dialog>

            <Dialog open={isRepaymentOpen} onOpenChange={setIsRepaymentOpen}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Bayar Cicilan / Lunas</DialogTitle>
                        <DialogDescription>
                            Masukkan nominal pembayaran untuk pelunasan nota ini.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-2">
                        <div className="flex justify-between items-center bg-muted/30 p-3 rounded-lg">
                            <Label>Nominal Pembayaran</Label>
                            <Input 
                                type="number" 
                                value={paymentAmount} 
                                onChange={(e) => setPaymentAmount(Number(e.target.value))}
                                className="w-40 text-right font-bold"
                            />
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setIsRepaymentOpen(false)}>Batal</Button>
                        <Button onClick={() => setIsRepaymentConfirmOpen(true)} disabled={paymentAmount <= 0}>
                            Simpan Pembayaran
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            <AlertDialog open={isRepaymentConfirmOpen} onOpenChange={setIsRepaymentConfirmOpen}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Konfirmasi Pembayaran</AlertDialogTitle>
                        <AlertDialogDescription>
                            Simpan pembayaran sebesar {formatRupiah(paymentAmount)}?
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel>Batal</AlertDialogCancel>
                        <AlertDialogAction onClick={handleRepayment}>Ya, Simpan</AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>

            <AlertDialog open={isConfirmOpen} onOpenChange={setIsConfirmOpen}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Konfirmasi Pembatalan</AlertDialogTitle>
                        <AlertDialogDescription>
                            Apakah Anda yakin ingin membatalkan transaksi ini?
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <div className="py-2 space-y-2">
                        <Label>Alasan Pembatalan</Label>
                        <Textarea 
                            value={cancellationReason}
                            onChange={(e) => setCancellationReason(e.target.value)}
                            placeholder="Masukkan alasan..."
                        />
                    </div>
                    <AlertDialogFooter>
                        <AlertDialogCancel>Batal</AlertDialogCancel>
                        <AlertDialogAction onClick={handleAjukanPembatalan} className="bg-destructive text-destructive-foreground">Ya, Batalkan</AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>

            <AlertDialog open={isFinalizeOpen} onOpenChange={setIsFinalizeOpen}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Selesaikan Transaksi</AlertDialogTitle>
                        <AlertDialogDescription>
                            Pilih opsi tanggal untuk menyelesaikan transaksi draft ini.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter className="flex-col sm:flex-row gap-2">
                        <Button variant="outline" onClick={() => setIsFinalizeOpen(false)} className="w-full sm:w-auto">Batal</Button>
                        <Button variant="secondary" onClick={() => handleFinalize(false)} className="w-full sm:w-auto">Gunakan Tgl Draft</Button>
                        <Button onClick={() => handleFinalize(true)} className="w-full sm:w-auto">Ubah ke Hari Ini</Button>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </div>
    </MainLayout>
  );
}
