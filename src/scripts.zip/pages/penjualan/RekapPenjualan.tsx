import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useDatabase } from '@/contexts/DatabaseContext';
import { formatRupiah, formatCompactRupiah } from '@/lib/utils';
import { BarChart, TrendingUp, Calendar, ArrowLeft, Wallet, CreditCard, Receipt, User, Coins } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

import { useAuth } from '@/contexts/AuthContext';

export default function RekapPenjualan() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { penjualan, pelanggan, users, karyawan, viewMode } = useDatabase();
  const [startDate, setStartDate] = useState(() => {
    return new Date().toLocaleDateString('sv').split('T')[0];
  });
  const [endDate, setEndDate] = useState(() => {
    return new Date().toLocaleDateString('sv').split('T')[0];
  });
  
  const [showDetailed, setShowDetailed] = useState(false);

  // Scope Filtering: "Sub-database" logic
  const isAdminOrOwner = user?.roles.includes('admin') || user?.roles.includes('owner');
  const isLeader = user?.roles.includes('leader');

  const scopedPenjualan = penjualan.filter(p => {
      if (isAdminOrOwner) {
          if (viewMode === 'me') return p.salesId === user?.id || p.createdBy === user?.id;
          return true;
      }
      if (p.cabangId !== user?.cabangId) return false;
      if (isLeader) {
          if (viewMode === 'me') return p.salesId === user?.id || p.createdBy === user?.id;
          return true;
      }
      return p.salesId === user?.id; // Sales only see their own data
  });

  const filtered = scopedPenjualan.filter(p => {
    const d = new Date(p.tanggal).toISOString().split('T')[0];
    return d >= startDate && d <= endDate;
  });

  const totalOmzet = filtered.reduce((sum, p) => sum + p.total, 0);
  const totalTrx = filtered.length;
  const tunai = filtered.filter(p => p.metodePembayaran === 'tunai').reduce((sum, p) => sum + p.total, 0);
  const kredit = filtered.filter(p => p.metodePembayaran === 'tempo').reduce((sum, p) => sum + p.total, 0);

  const formatCurrency = (amount: number) => {
      return showDetailed ? formatRupiah(amount) : formatCompactRupiah(amount);
  };

  return (
    <MainLayout title="Rekap Penjualan">
      <div className="p-4 max-w-5xl mx-auto space-y-6">
        <div className="flex items-center gap-2">
            <Button 
            variant="ghost" 
            size="sm"
            onClick={() => navigate('/penjualan')}
            className="-ml-2 text-muted-foreground hover:text-foreground"
            >
            <ArrowLeft className="w-4 h-4 mr-1" />
            Kembali
            </Button>
        </div>

        {/* Filter Section */}
        <Card className="border-none shadow-sm bg-background/50 backdrop-blur-sm">
          <CardContent className="p-4 sm:p-6">
            <div className="flex flex-col sm:flex-row items-end justify-between gap-4">
                <div className="w-full sm:flex-1 space-y-3">
                    <div className="flex items-center gap-2 text-primary font-medium">
                        <Calendar className="w-4 h-4" />
                        <span>Periode Laporan</span>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                            <span className="text-xs text-muted-foreground ml-1">Dari Tanggal</span>
                            <Input 
                                type="date" 
                                value={startDate} 
                                onChange={e => setStartDate(e.target.value)} 
                                onClick={(e) => (e.target as HTMLInputElement).showPicker()}
                                className="bg-background cursor-pointer"
                            />
                        </div>
                        <div className="space-y-1.5">
                            <span className="text-xs text-muted-foreground ml-1">Sampai Tanggal</span>
                            <Input 
                                type="date" 
                                value={endDate} 
                                onChange={e => setEndDate(e.target.value)} 
                                onClick={(e) => (e.target as HTMLInputElement).showPicker()}
                                className="bg-background cursor-pointer"
                            />
                        </div>
                    </div>
                </div>

                <div className="flex items-center space-x-2 bg-background border rounded-lg p-2 h-10">
                    <Switch 
                        id="currency-mode" 
                        checked={showDetailed} 
                        onCheckedChange={setShowDetailed} 
                    />
                    <Label htmlFor="currency-mode" className="text-xs font-medium cursor-pointer flex items-center gap-1.5">
                        <Coins className="w-3.5 h-3.5 text-muted-foreground" />
                        {showDetailed ? 'Detail (Rp)' : 'Singkat (K)'}
                    </Label>
                </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
           {/* Total Omzet */}
           <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20 shadow-sm relative overflow-hidden">
             <div className="absolute top-0 right-0 p-3 opacity-10">
                <TrendingUp className="w-12 h-12 sm:w-16 sm:h-16" />
             </div>
             <CardContent className="p-4 sm:p-5 flex flex-col justify-between h-full relative z-10">
               <div>
                   <p className="text-xs sm:text-sm font-medium text-muted-foreground">Total Omzet</p>
                   <p className={`font-bold text-primary mt-1 tracking-tight ${showDetailed ? 'text-lg sm:text-l' : 'text-lg sm:text-2xl'}`}>
                        {formatCurrency(totalOmzet)}
                   </p>
               </div>
               <div className="mt-2 w-6 sm:w-8 h-1 bg-primary/20 rounded-full" />
             </CardContent>
           </Card>

           {/* Total Transaksi */}
           <Card className="bg-gradient-to-br from-blue-500/10 to-blue-500/5 border-blue-500/20 shadow-sm relative overflow-hidden">
             <div className="absolute top-0 right-0 p-3 opacity-10">
                <Receipt className="w-12 h-12 sm:w-16 sm:h-16 text-blue-600" />
             </div>
             <CardContent className="p-4 sm:p-5 flex flex-col justify-between h-full relative z-10">
               <div>
                   <p className="text-xs sm:text-sm font-medium text-muted-foreground">Total Transaksi</p>
                   <p className="text-lg sm:text-2xl font-bold text-blue-700 mt-1 tracking-tight">{totalTrx} <span className="text-xs sm:text-sm font-normal text-muted-foreground">Nota</span></p>
               </div>
                <div className="mt-2 w-6 sm:w-8 h-1 bg-blue-500/20 rounded-full" />
             </CardContent>
           </Card>

           {/* Tunai */}
           <Card className="bg-gradient-to-br from-emerald-500/10 to-emerald-500/5 border-emerald-500/20 shadow-sm relative overflow-hidden">
             <div className="absolute top-0 right-0 p-3 opacity-10">
                <Wallet className="w-12 h-12 sm:w-16 sm:h-16 text-emerald-600" />
             </div>
             <CardContent className="p-4 sm:p-5 flex flex-col justify-between h-full relative z-10">
               <div>
                   <p className="text-xs sm:text-sm font-medium text-muted-foreground">Tunai</p>
                   <p className={`font-bold text-emerald-700 mt-1 tracking-tight ${showDetailed ? 'text-lg sm:text-l' : 'text-lg sm:text-2xl'}`}>
                        {formatCurrency(tunai)}
                   </p>
               </div>
               <div className="mt-2 w-6 sm:w-8 h-1 bg-emerald-500/20 rounded-full" />
             </CardContent>
           </Card>

           {/* Kredit */}
           <Card className="bg-gradient-to-br from-amber-500/10 to-amber-500/5 border-amber-500/20 shadow-sm relative overflow-hidden">
             <div className="absolute top-0 right-0 p-3 opacity-10">
                <CreditCard className="w-12 h-12 sm:w-16 sm:h-16 text-amber-600" />
             </div>
             <CardContent className="p-4 sm:p-5 flex flex-col justify-between h-full relative z-10">
               <div>
                   <p className="text-xs sm:text-sm font-medium text-muted-foreground">Piutang</p>
                   <p className={`font-bold text-amber-700 mt-1 tracking-tight ${showDetailed ? 'text-lg sm:text-l' : 'text-lg sm:text-2xl'}`}>
                        {formatCurrency(kredit)}
                   </p>
               </div>
               <div className="mt-2 w-6 sm:w-8 h-1 bg-amber-500/20 rounded-full" />
             </CardContent>
           </Card>
        </div>

        {/* Transaction List */}
        <div className="space-y-4">
            <div className="flex items-center justify-between px-1">
                <h3 className="font-semibold text-lg tracking-tight">Rincian Penjualan</h3>
                <Badge variant="outline" className="text-xs font-normal">
                    {filtered.length} Transaksi Ditemukan
                </Badge>
            </div>

            <Card className="border-none shadow-sm overflow-hidden">
                <div className="divide-y divide-border/50">
                    {filtered.length === 0 ? (
                        <div className="py-12 flex flex-col items-center justify-center text-center space-y-3">
                            <div className="w-16 h-16 bg-muted/30 rounded-full flex items-center justify-center">
                                <Receipt className="w-8 h-8 text-muted-foreground/40" />
                            </div>
                            <div className="space-y-1">
                                <p className="font-medium text-muted-foreground">Tidak ada data penjualan</p>
                                <p className="text-xs text-muted-foreground/60">Coba atur ulang filter tanggal diatas</p>
                            </div>
                        </div>
                    ) : (
                        filtered.map(item => {
                            const customer = pelanggan.find(c => c.id === item.pelangganId);
                            const customerName = (customer?.nama || 'Umum').toUpperCase();

                            const salesId = item.salesId || item.createdBy;
                            const linkedEmployee = karyawan.find(k => k.userAccountId === salesId);
                            const salesPerson = users.find(u => u.id === salesId);
                            const salesName = linkedEmployee?.nama || salesPerson?.nama || 'Sales';
                            
                            return (
                                <div key={item.id} className="group p-3 sm:p-4 hover:bg-muted/30 transition-colors flex flex-col sm:flex-row items-stretch sm:items-center gap-3 sm:gap-4">
                                    {/* Header Row: Icon, No Nota, Date (Mobile: Top, Desktop: Left) */}
                                    <div className="flex items-center gap-3 min-w-[140px]">
                                        <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                                            <Receipt className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
                                        </div>
                                        <div>
                                            <p className="font-semibold text-sm">{item.nomorNota}</p>
                                            <p className="text-[10px] sm:text-xs text-muted-foreground">
                                                {new Date(item.tanggal).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}
                                            </p>
                                        </div>
                                        {/* Mobile Only: Amount on right of header */}
                                        <div className="sm:hidden ml-auto text-right">
                                            <p className="font-bold text-sm text-foreground">{formatRupiah(item.total)}</p>
                                        </div>
                                    </div>

                                    {/* Customer & Sales */}
                                    <div className="flex-1 grid grid-cols-2 gap-2 sm:gap-4 w-full pl-11 sm:pl-0">
                                        <div className="space-y-0.5 sm:space-y-1">
                                            <p className="text-[9px] sm:text-[10px] uppercase text-muted-foreground font-bold tracking-wider">Pelanggan</p>
                                            <p className="text-xs sm:text-sm font-medium truncate">{customerName}</p>
                                        </div>
                                        <div className="space-y-0.5 sm:space-y-1">
                                            <p className="text-[9px] sm:text-[10px] uppercase text-muted-foreground font-bold tracking-wider">Sales</p>
                                            <div className="flex items-center gap-1">
                                                <User className="w-3 h-3 text-muted-foreground" />
                                                <p className="text-xs sm:text-sm truncate">{salesName}</p>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Desktop: Amount & Status. Mobile: Status only (Amount in header) */}
                                    <div className="flex justify-between sm:block sm:text-right min-w-[120px] self-end sm:self-center pl-11 sm:pl-0 w-full sm:w-auto mt-1 sm:mt-0">
                                         {/* Desktop Amount */}
                                        <p className="hidden sm:block font-bold text-base text-foreground">{formatRupiah(item.total)}</p>
                                        
                                        <Badge variant={item.metodePembayaran === 'tunai' ? 'success' : 'warning'} className="text-[10px] uppercase px-2 h-5">
                                            {item.metodePembayaran}
                                        </Badge>
                                    </div>
                                </div>
                            );
                        })
                    )}
                </div>
            </Card>
        </div>
      </div>
    </MainLayout>
  );
}
